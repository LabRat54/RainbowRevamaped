package labrat.rainbowrevamped.crafting;

public class RainbowCraftingTableManager {
}
