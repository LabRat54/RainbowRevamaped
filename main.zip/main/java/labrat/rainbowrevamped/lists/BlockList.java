package labrat.rainbowrevamped.lists;

import net.minecraft.block.Block;

public class BlockList {

    public static Block rainbow_crafting_table;
    public static final int guiIDRainbowCraftingTable = 0;
}
