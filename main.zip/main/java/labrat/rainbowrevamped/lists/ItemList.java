package labrat.rainbowrevamped.lists;

import net.minecraft.item.Item;

public class ItemList {

    public static Item rct_block;
}
